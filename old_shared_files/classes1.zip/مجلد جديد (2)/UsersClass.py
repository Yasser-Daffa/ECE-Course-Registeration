from DataClass import Database
from DataClass import con, cur



db = Database(con, cur)



class User:
    def __init__(self, db):
        self.db = db
        self.user_id = None
        self.name = None
        self.email = None
        self.program = None
        self.state = None
        self.account_status = None

    def add_users(self):

        name = input("Enter user name: ").strip()
        email = input("Enter email: ").strip()

        password = input("Enter password: ").strip()

        program = input("Enter program (PWM/BIO/COMM/COMP or leave empty): ").strip()
        if not program:
            program = None

        #  نحدد نوع الحساب (طالب/أستاذ/أدمن)
        state = input("Enter state ('admin','student','instructor'): ").strip()

        #  نولد كود التفعيل
        verify_code = random.randint(100000, 999999)

        subject = "verification code for your account"
        body = (
            f"Hello {name},\n\n"
            f"Your verification code is: {verify_code}\n\n"
            f"Please enter this code in the application to complete your registration."
        )

        send_email(email, subject, body)
        print("Verification code sent to your email.")

        entered = input("Enter the verification code sent to your email: ").strip()

        if entered != str(verify_code):
            print("Verification code is incorrect. Registration cancelled.")
            return

        msg = self.db.add_users(name, email, password, program, state)
        print(msg)

    def Admin_list_users(self):
        users = self.db.list_users()

        for user_id, name, email, program, state,account_status in users:
            print(user_id, name, account_status)

    def Admin_update_my_info(self, user_id):

        change_name = input("Change name? (yes/no): ").strip().lower() == 'yes' #false
        change_email = input("Change email? (yes/no): ").strip().lower() == 'yes' #true
        change_program = input("Change program? (yes/no): ").strip().lower() == 'yes'  #false
        change_password = input("Change password? (yes/no): ").strip().lower() == 'yes' #true
        change_status = input("Change account status (active/inactive)? (yes/no): ").strip().lower() == 'yes' #false

        if change_name:
            new_name = input("New name: ").strip()
        else:
            new_name = None

        if change_email:
            new_email = input("New email: ").strip()
        else:
            new_email = None

        if change_program:
            new_program = input("New program (PWM/BIO/COMM/COMP): ").strip().upper()
        else:
            new_program = None

        if change_password:
            new_password = input("New password: ").strip()
        else:
            new_password = None

        if change_status:
            new_status = input("New account status ('active'/'inactive'): ").strip()
        else:
            new_status = None

        msg = self.db.update_user(
            user_id=user_id,
            name=new_name,
            email=new_email,
            program=new_program,
            password=new_password,
            account_status=new_status,
        )

        print(msg)
        return msg

    def login(self, user_id, password):


        row = self.db.user_login(user_id, password)

        if row is None:
            print("Invalid ID or password.")
            return None  # يعني تسجيل الدخول فشل

        db_user_id, name, email, program, state, account_status = row

        if account_status != "active":
            print("Your account is not activated yet.")
            return None

        self.user_id = db_user_id
        self.name = name
        self.email = email
        self.program = program
        self.state = state
        self.account_status = account_status

        if state == "student":
            print("Opening student ")
        elif state == "admin":
            print("Opening admin main ")
        elif state == "instructor":
            print("Opening instructor ")

        return state

    def reset_password_outside(self):

        user_id = input("Enter your ID: ").strip()
        email = input("Enter your email: ").strip()

        try:
            user_id = int(user_id)
        except ValueError:
            print("ID must be a number.")
            return

        reset_code = random.randint(100000, 999999)

        subject = "Reset password code"
        body = (
            f"Hello,\n\n"
            f"Your reset password code is: {reset_code}\n\n"
            f"If you did not request this, ignore this email.")

        send_email(email, subject, body)
        print("Reset code sent to your email.")

        # التحقق من الكود
        entered = input("Enter the reset code you received: ").strip()
        if entered != str(reset_code):
            print("Reset code is incorrect. Cancelled.")
            return

        # لو الكود صحيح نطلب باسورد جديد
        new_pass = input("Enter your new password: ").strip()

        msg = self.db.reset_password_with_email(user_id, email, new_pass)
        print(msg)




user = User(db)
