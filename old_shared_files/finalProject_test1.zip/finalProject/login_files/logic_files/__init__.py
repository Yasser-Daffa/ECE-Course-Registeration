import sys
from PyQt6.QtWidgets import QApplication
from login_files.ui_files.class_create_account_widget import BaseLoginForm

app = QApplication(sys.argv)
window = BaseLoginForm()  # or your actual widget
window.show()
sys.exit(app.exec())
