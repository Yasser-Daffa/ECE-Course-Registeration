# ================================================================
# ConfirmEmailLogic
# Handles: entering code, resending, and countdown.
# ================================================================

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QMessageBox

from helper_files.shared_utilities import CodeGenerator, EmailSender
from helper_files.validators import validate_email, validate_full_name, hash_password
from login_files.ui_files.class_confirm_email_widget import ConfirmEmailWidget

import sqlite3
# --- Initialize database and ensure all tables exist ---
# Import the function that sets up the database schema if not already present
from database_files.initialize_database import initialize_database
from database_files.class_database_uitlities import DatabaseUtilities


class AccountCreationFlow:
    # ----- INIT -----
    def __init__(self):

        self.create_acc_ui = ConfirmEmailWidget

        # Call it to create/connect the database and return the connection and cursor
        # This ensures all required tables, triggers, and constraints exist
        con, cur = initialize_database("university_database.db")  # runs the table creation if missing

        # Wrap the connection and cursor in your DatabaseUtilities helper for easy DB operations
        self.db = DatabaseUtilities(con, cur)

        # ----- Temp storage -----
        self.new_user_data = {}

        # ----- Utilities -----
        self.code_generator = CodeGenerator(validity_minutes=5)
        self.email_sender = EmailSender()

        # ----- Timer for resend -----
        self.cooldown_timer = QTimer()
        self.cooldown_timer.setInterval(1000)
        self.cooldown_timer.timeout.connect(self.update_timer)
        self.seconds_left = 0

        self.connect_signals()

    # ----- Connect signals -----
    def connect_signals(self):
        self.create_ui.createAccountButton.clicked.connect(self.handle_create)
        self.confirm_ui.buttonVerifyCode.clicked.connect(self.handle_confirmation)
        self.confirm_ui.buttonReSendCode.clicked.connect(self.resend_code)

    # ----- Handle Create Account Click -----
    def handle_create(self):
        full_name_raw = self.create_ui.fullName.text().strip()
        email_raw = self.create_ui.email.text().strip()
        password_raw = self.create_ui.password.text()
        program_text = self.create_ui.comboBoxProgram.currentText()
        label = self.create_ui.labelGeneralStatus

        # ----- Validate -----
        parts, error = validate_full_name(full_name_raw)
        if error:
            label.setText(error)
            label.setStyleSheet("color: red;")
            return
        full_name = " ".join(parts)

        err = validate_email(email_raw)
        if err:
            label.setText(err)
            label.setStyleSheet("color: red;")
            return

        program_map = {"Computer": "COMP", "Communication": "COMM",
                       "Power": "PWM", "Biomedical": "BIO"}
        if program_text not in program_map:
            label.setText("Please select a program.")
            label.setStyleSheet("color: red;")
            return
        program_value = program_map[program_text]

        if self.db.check_email_exists(email_raw):
            label.setText("Email already exists.")
            label.setStyleSheet("color: red;")
            return

        # ----- Store user temporarily -----
        self.new_user_data = {
            "name": full_name,
            "email": email_raw,
            "password": password_raw,
            "program": program_value,
            "state": "student"
        }

        # ----- Send code -----
        if self.send_verification_code(email_raw):
            label.setText("Verification code sent!")
            label.setStyleSheet("color: green;")
        self.go_to_confirm()

    # ----- Send verification code -----
    def send_verification_code(self, email):
        code = self.code_generator.generate_verification_code()
        subject = "Verification Code"
        body = f"Your code: {code}\nExpires in {self.code_generator.validity_minutes} min."
        sent = self.email_sender.send_email(email, subject, body)
        if sent:
            self.start_cooldown()
        return sent

    # ----- Go to confirm page -----
    def go_to_confirm(self):
        self.stacked_widget.setCurrentWidget(self.confirm_ui)

    # ----- Cooldown timer -----
    def start_cooldown(self):
        self.seconds_left = 60
        self.confirm_ui.labelTimer.setText("60")
        self.confirm_ui.buttonReSendCode.setEnabled(False)
        self.cooldown_timer.start()

    def update_timer(self):
        self.seconds_left -= 1
        if self.seconds_left > 0:
            self.confirm_ui.labelTimer.setText(str(self.seconds_left))
        else:
            self.cooldown_timer.stop()
            self.confirm_ui.labelTimer.setText("You can request a new code now.")
            self.confirm_ui.buttonReSendCode.setEnabled(True)

    # ----- Check if code is valid -----
    def check_valid_code(self, code):
        if not code:
            return False, "Code cannot be empty."
        if code != self.code_generator.code:
            return False, "Incorrect code."
        if self.code_generator.is_code_expired():
            return False, "Code expired."
        return True, ""

    # ----- Handle confirmation -----
    def handle_confirmation(self):
        code = self.confirm_ui.lineEditVerificationCode.text().strip()
        valid, msg = self.check_valid_code(code)
        if not valid:
            QMessageBox.warning(self.confirm_ui, "Invalid Code", msg)
            return
        self.complete_account_creation()

    # ----- Complete account creation -----
    def complete_account_creation(self):
        hashed = hash_password(self.new_user_data["password"])
        result = self.db.add_users(self.new_user_data["name"],
                                   self.new_user_data["email"],
                                   hashed,
                                   self.new_user_data["program"],
                                   "student")
        if "successfully" in result:
            QMessageBox.information(self.confirm_ui, "Success",
                                    "Account created! Wait for admin approval.")
            self.stacked_widget.setCurrentIndex(0)
        else:
            QMessageBox.critical(self.confirm_ui, "Error", result)

    # ----- Resend code -----
    def resend_code(self):
        email = self.new_user_data["email"]
        self.send_verification_code(email)
