import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PyQt6.QtWidgets import QApplication

from login_files.ui_files.class_create_account_widget import CreateAccountWidget
from helper_files.shared_utilities import CodeGenerator, EmailSender

import login_files.login_resources_rc



# class_create_account_widget.py
from PyQt6.QtWidgets import QWidget, QMessageBox
from PyQt6.QtCore import QTimer
from helper_files.validators import validate_full_name, validate_email

# ================================================================
# CreateAccountLogic
# Handles: full name validation, email validation, program selection,
# password, sending verification code, and switching to confirmation page.
# ================================================================

class CreateAccountLogic:
    def __init__(self, db, stacked_widget, create_page, confirm_page, confirm_logic):
        self.db = db
        self.stacked_widget = stacked_widget
        self.create_account_page = create_page
        self.confirm_email_page = confirm_page
        self.confirm_logic = confirm_logic
        self.new_user_data = {}

        self.connect_signals()

    def connect_signals(self):
        self.create_account_page.createAccountButton.clicked.connect(self.handle_create_account_click)

    def handle_create_account_click(self):
        raw_full_name = self.create_account_page.fullName.text().strip()
        raw_email = self.create_account_page.email.text().strip()
        raw_password = self.create_account_page.password.text()
        selected_program_text = self.create_account_page.comboBoxProgram.currentText()

        labelStatus = self.create_account_page.labelGeneralStatus

        # ---------------- Validate full name ----------------
        full_name_parts, name_error = validate_full_name(raw_full_name)
        if name_error:
            labelStatus.setText(name_error)
            labelStatus.setStyleSheet("color: red;")
            return
        full_name = " ".join(full_name_parts)

        # ---------------- Validate email ----------------
        email_error = validate_email(raw_email)
        if email_error:
            labelStatus.setText(email_error)
            labelStatus.setStyleSheet("color: red;")
            return

        # ---------------- Validate program ----------------
        program_map = {"Computer": "COMP", "Communication": "COMM", "Power": "PWM", "Biomedical": "BIO"}
        if selected_program_text == "Select":
            labelStatus.setText("Please select a program.")
            labelStatus.setStyleSheet("color: red;")
            return

        program_value = program_map[selected_program_text]

        # ---------------- Check email exists ----------------
        if self.db.check_email_exists(raw_email):
            labelStatus.setText("Email already exists.")
            labelStatus.setStyleSheet("color: red;")
            return

        # ---------------- Store user temporarily ----------------
        self.new_user_data = {
            "name": full_name,
            "email": raw_email,
            "password": raw_password,
            "program": program_value,
            "state": "student"
        }

        # ---------------- Send verification code ----------------
        self.code_generator = CodeGenerator(validity_minutes=5)
        self.email_sender = EmailSender()

        code_sent = self.send_verification_code(raw_email)
        if code_sent:
            labelStatus.setText("Verification code sent!")
            labelStatus.setStyleSheet("color: green;")

        QTimer.singleShot(200, self.go_to_confirm_email)

    def send_verification_code(self, to_email: str) -> bool:
        code = self.code_generator.generate_verification_code()

        subject = "Your Verification Code"
        body = f"Your verification code is: {code}\nExpires in {self.code_generator.validity_minutes} minutes."

        sent = self.email_sender.send_email(to_email, subject, body)

        if sent:
            self.confirm_email_page.start_cooldown_timer()
        return sent

    def go_to_confirm_email(self):
        self.stacked_widget.setCurrentWidget(self.confirm_email_page)
        self.confirm_logic.prep(self.code_generator, self.new_user_data)



if __name__ == "__main__":
 
    app = QApplication(sys.argv)
    window = CreateAccountWidget()  # or your specific widget class
    window.show()
    sys.exit(app.exec())
    app = QApplication(sys.argv)