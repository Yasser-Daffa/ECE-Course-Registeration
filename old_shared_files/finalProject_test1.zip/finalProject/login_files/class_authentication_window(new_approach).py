# auth_window.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from PyQt6.QtWidgets import QStackedWidget, QWidget

from login_files.ui_files.class_create_account_widget import CreateAccountWidget
from login_files.ui_files.class_confirm_email_widget import ConfirmEmailWidget

from login_files.logic_files.class_create_account_logic import CreateAccountLogic
from login_files.logic_files.class_confirm_email_logic import ConfirmEmailLogic


class AuthWindow(QWidget):
    def __init__(self, db):
        super().__init__()

        self.stacked = QStackedWidget(self)

        # ----- Pages -----
        self.create_page = CreateAccountWidget()
        self.confirm_page = ConfirmEmailWidget()

        self.stacked.addWidget(self.create_page)
        self.stacked.addWidget(self.confirm_page)

        # ----- Logic -----
        self.confirm_logic = ConfirmEmailLogic(
            stacked_widget=self.stacked,
            confirm_page_widget=self.confirm_page,
            db=db,
            code_generator=None  # will be injected from create logic
        )

        self.create_logic = CreateAccountLogic(
            stacked_widget=self.stacked,
            create_page_widget=self.create_page,
            confirm_logic=self.confirm_logic,
            db=db
        )

        # link the code generator
        self.confirm_logic.code_generator = self.create_logic.code_generator

        # ----- Signals -----
        self.create_logic.connect_signals()
        self.confirm_logic.connect_signals()
