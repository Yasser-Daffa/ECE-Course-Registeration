import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtCore import QTimer
import sqlite3

# UI + Page Classes
from ui_auth_stackedwidget_view_only import Ui_AuthStackedWidget #  View-only version
from class_login_widget import LoginWidget
from class_create_account_widget import CreateAccountWidget 
from class_reset_password_widget import ResetPasswordWidget
from class_confirm_email_widget import ConfirmEmailWidget

# Shared base class (password toggles, animations, etc.)
from login_helper_functions import BaseLoginForm 

# DB utilities
from database_files.class_database_uitlities import DatabaseUtilities

# Placeholder imports for your future main windows
# from student_dashboard.class_student_dashboard import StudentDashboard
# from admin_dashboard.class_admin_dashboard import AdminDashboard




class AuthenticationWindow(BaseLoginForm): 
    def __init__(self):
        super().__init__()

        # Load UI
        self.ui = Ui_AuthStackedWidget()
        self.ui.setupUi(self)
        
        # Instantiate the real widgets
        self.login_page = LoginWidget(None)
        self.reset_password_confirm_email_page = ResetPasswordWidget(None)
        self.create_account_page = CreateAccountWidget(None)
        self.confirm_email_page = ConfirmEmailWidget(None)

        # -----------------------------------------------------
        # 4) Inject shared DB into each widget
        # -----------------------------------------------------
        # self.login_page.set_database(self.db)
        # self.create_account_page.set_database(self.db)
        # self.reset_password_page.set_database(self.db)
        # self.confirm_email_page.set_database(self.db)

        # Starting page
        self.ui.stackedWidgetAuth.setCurrentIndex(0)
        # ---- Login Page --- to other pages ----
        self.login_page.ui.buttonCreateAccount.clicked.connect(self.go_to_create_account)
        self.login_page.ui.buttonResetPassword.clicked.connect(self.go_to_reset)
        # ---- Create Account --- to other pages ----
        self.create_account_page.ui.buttonLoginHere.clicked.connect(self.go_to_login)
        self.create_account_page.ui.buttonCreateAccount.clicked.connect(self.go_to_confirm_email)
        # ---- Reset Password Widget/Change Password Dialog --- to other pages ----
        self.reset_password_confirm_email_page.ui.buttonBackToSignIn.clicked.connect(self.go_to_login)
        # ---- Confirm Email Page --- to other pages ----
        self.confirm_email_page.ui.buttonBackToCreateAccount.clicked.connect(self.handle_back_to_create_account)
        self.confirm_email_page.ui.buttonBackToSignIn.clicked.connect(self.handle_back_to_sign_in)

        # --- 4. Connect Action Signals ---
        self.login_page.ui.buttonLogin.clicked.connect(self.handle_login)


        # --- 5. For email confirmation widget ---
        # resend code button locked at the beginning
        # self.confirm_email_page.buttonReSendCode.setEnabled(False)
        # # after widget loads → send email
        # QTimer.singleShot(300, self.start_process) 

    # =========================================================
    #                     NAVIGATION
    # =========================================================

    def go_to_login(self):
        print("Switching back to login page...")
        self.ui.stackedWidgetAuth.setCurrentIndex(0) # Switch back to the LoginWidget

    def go_to_create_account(self):
        print("Switching to create account page...")
        self.ui.stackedWidgetAuth.setCurrentIndex(1) # Switch to the CreateAccountWidget

    def go_to_reset(self):
        """ If the user clickes on the reset password button it will open this page"""
        print("Switching to reset pasword page")
        self.ui.stackedWidgetAuth.setCurrentIndex(2)
    
    def open_password_reset_outside(self):
        """If password and confirm password match it will
            redirect the user to the reset password window. """
        print("Openning password reset dialog")
        self.ui.stackedWidgetAuth.setCurrentIndex(3)
    
    def go_to_confirm_email(self):
        print("Switching to email confirmation page...")
        self.ui.stackedWidgetAuth.setCurrentIndex(3) # Switch to the ConfirmEmailWidget


    # =========================================================
    #                     LOGIN LOGIC
    # =========================================================

    def handle_login(self):
        # *** This is where you transition to the main application ***
        username = self.login_page.ui.lineEditUsername.text() 
        password = self.login_page.ui.lineEditPassword.text()

        print(f"Attempting login for: {username}")
        
        # --- Dummy Login Check ---
        if username == "student" and password == "123":
            print("Login successful. Opening Student Dashboard.")
            # self.student_dash = StudentDashboard() 
            # self.student_dash.show()
            self.close() # Close the AuthWindow

        elif username == "admin" and password == "admin":
            print("Login successful. Opening Admin Dashboard.")
            # self.admin_dash = AdminDashboard()
            # self.admin_dash.show()
            self.close() # Close the AuthWindow
            
        else:
            print("Login Failed.")
            return "failed"
            # (Show error message on login page)


    def handle_account_creation(self):
        print("Handling user account creation...")

        # Here you would handle the account creation logic
        # Access the exposed status label on the create account page
        labelGeneralStatus = self.create_account_page.labelGeneralStatus
        

        # --- 2. Account Creation Logic ---
        
        existing_style = labelGeneralStatus.styleSheet()

        labelGeneralStatus.setStyleSheet(
            existing_style +
            "color: green;"
        )

        labelGeneralStatus.setText("Success! Account created. Redirecting to login...")
        
        # 3. Use a QTimer to wait a moment before switching pages
        from PyQt6.QtCore import QTimer
        
        # This line schedules the 'go_to_confirm_email' function to run after 1000 milliseconds (1 second)
        QTimer.singleShot(1000, self.go_to_confirm_email)
    
    def handle_email_confirmation(self):

        print("Handling email confirmation...")

        # Here you would handle the email confirmation logic
        # For example, verify the code entered by the user
        entered_code = self.confirm_email_page.lineEditVerificationCode.text()
        print(f"User entered confirmation code: {entered_code}")
        # Simulate successful confirmation
        QMessageBox.information(self, "Email Confirmed", "Your email has been successfully confirmed" \
        "Please wait till you get accepted into the system. and try to login again.")
        QTimer.singleShot(1000, self.go_to_login)


    def handle_back_to_create_account(self):
        response = self.show_confirmation(
            "Are you sure?",
            "Going back might cancel the registration process."
        )

        if response == QMessageBox.StandardButton.Yes:
            self.go_to_create_account()   # or whatever your navigation method is


    def handle_back_to_sign_in(self):
        response = self.show_confirmation(
            "Are you sure?",
            "Going back might cancel the registration process."
        )

        if response == QMessageBox.StandardButton.Yes:
            self.go_to_login()  # navigate to login page







if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AuthenticationWindow() 
    window.show()
    sys.exit(app.exec())