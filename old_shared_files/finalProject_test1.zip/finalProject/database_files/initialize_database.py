# initialize_database.py
# ----------------------------------------
# This module initializes the SQLite database for the application.
# It ensures all required tables and triggers exist according to the schema.
# If the database file 'university_database.db' does not exist, it will be created.
# If the database file already exists, it will not be overwritten, but missing tables will be created.
# Call the 'initialize_database()' function at application startup to safely set up the database.
# ----------------------------------------

def initialize_database(db_path="university_database.db"):
    import sqlite3
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("PRAGMA foreign_keys = ON;")

    # --- USERS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        program TEXT CHECK(program IN ('PWM','BIO','COMM','COMP')),
        password_h TEXT NOT NULL,
        state TEXT NOT NULL CHECK(state IN ('admin','student','instructor')),
        account_status TEXT NOT NULL DEFAULT 'inactive' CHECK(account_status IN ('active','inactive'))
    );
    """)

    # --- LOGIN ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS login(
        user_id INTEGER NOT NULL,
        last_login TEXT,
        FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE
    );
    """)

    # --- COURSES ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS courses(
        name TEXT NOT NULL,
        code TEXT PRIMARY KEY,
        credits INTEGER NOT NULL CHECK(credits>=0)
    );
    """)

    # --- REQUIRES ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS requires(
        course_code TEXT NOT NULL,
        prereq_code TEXT NOT NULL,
        PRIMARY KEY(course_code, prereq_code),
        CHECK(course_code != prereq_code),
        FOREIGN KEY(course_code) REFERENCES courses(code) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY(prereq_code) REFERENCES courses(code) ON DELETE CASCADE ON UPDATE CASCADE
    );
    """)

    # --- SECTIONS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sections(
        section_id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_code TEXT NOT NULL,
        doctor_id INTEGER,
        days TEXT,
        time_start TEXT,
        time_end TEXT,
        room TEXT,
        capacity INTEGER NOT NULL CHECK(capacity >= 0),
        enrolled INTEGER NOT NULL CHECK(enrolled >= 0 AND enrolled <= capacity),
        semester TEXT NOT NULL,
        state TEXT NOT NULL CHECK(state IN ('open','closed')),
        UNIQUE(course_code, section_id, semester),
        UNIQUE(doctor_id, days, time_start, time_end),
        FOREIGN KEY(course_code) REFERENCES courses(code) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY(doctor_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE
    );
    """)

    # --- STUDENTS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS students(
        student_id INTEGER PRIMARY KEY,
        level INTEGER CHECK(level >= 1),
        FOREIGN KEY(student_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE
    );
    """)

    # --- REGISTRATIONS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS registrations(
        student_id INTEGER NOT NULL,
        section_id INTEGER NOT NULL,
        PRIMARY KEY(student_id, section_id),
        FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY(section_id) REFERENCES sections(section_id) ON DELETE CASCADE ON UPDATE CASCADE
    );
    """)

    # --- TRANSCRIPTS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS transcripts(
        student_id INTEGER NOT NULL,
        course_code TEXT NOT NULL,
        semester TEXT NOT NULL,
        grade TEXT,
        PRIMARY KEY(student_id, course_code, semester),
        FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY(course_code) REFERENCES courses(code) ON UPDATE CASCADE
    );
    """)

    # --- PROGRAM PLANS ---
    cur.execute("""
    CREATE TABLE IF NOT EXISTS program_plans(
        program TEXT NOT NULL,
        level INTEGER NOT NULL CHECK(level >= 1),
        course_code TEXT NOT NULL,
        PRIMARY KEY(program, level, course_code),
        FOREIGN KEY(course_code) REFERENCES courses(code) ON DELETE RESTRICT ON UPDATE CASCADE
    );
    """)

    con.commit()
    return con, cur
